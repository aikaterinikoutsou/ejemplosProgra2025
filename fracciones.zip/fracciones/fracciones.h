#ifndef FRACCIONES
#define FRACCIONES

typedef struct {
    int num;
    int denum;
}Fraccion;

extern Fraccion multiplicarFracciones(Fraccion fr1, Fraccion fr2);

#endif // FRACCIONES



